**=========================================================================
**
** Blogger Template Style
** Name:         VTrick - Creative Blogger Template
** Version:      v1.8.26 - Sept 11th, 2021
** Download:     https://www.vietrick.com/vtrick-creative-blogger-template
** Author:       Lê Hòa
** Author Url:   https://www.vietrick.com
**
**=========================================================================
**
** Template được phát hành miễn phí tại: VIETRICK
** Hướng dẫn cài đặt và cập nhật bản mới nhất tại: https://www.vietrick.com/vtrick-creative-blogger-template/
**
**=========================================================================
** Change logs:
**=========================================================================
v1.8.26 - Sept 11th, 2021
- Performance enhancement
- Shortcodes upgraded
- Social Sharing updated
- Related Post updated
- Image lazyload enhancement

- What's new in v1.8:
	- Multiple ADS position
	- Featured Image ratio 16:9
	- Threaded comment system
	- Advanced preload
	- DarkMode
	- Homepage Ticker news
	- Fake Post Rating
	- Floating CTA buttons
	- Mega menu
	- AJAX widget blocks
	- Reading time


v1.5.11 - May 11th, 2021
- Fix minor bug: homepage loadmore did not work on mobile
- Update related post layout

v1.4.14 - April 14th, 2021
- Update Homepage Sidebar
- Update Bullet List Style

v1.4.12 - April 12th, 2021
- Update Back to Top button

v1.4.08 - April 8th, 2021
- Add Disqus comment system.
- Show multiple tags on index post
- Update Numbered List Style
- Update side menu UI

v1.4.07 - April 7th, 2021
- Fix Trending/Featured Section Hidden Toggle.
- Add Facebook comment system.

v1.4.01 - April 1st, 2021
- Add Cookie Consent

v1.3.28 - March 28th, 2021
- Fix some minor layout bug

v1.3.02 – March 2nd, 2021
– Update Footer layout section

v1.2.28 – February 28, 2021
– Added AJAX comment on Homepage
– Update Shortcode / Typography

v1.2.23 – February 23, 2021
– Added Trending post

v1.0.0 – February 19, 2021
– Initial release
